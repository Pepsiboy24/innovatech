# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth.spec.js >> 1.3 parent cannot access /student
- Location: tests/auth.spec.js:77:3

# Error details

```
Error: expected access denial for parent on /student

expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Page snapshot

```yaml
- generic [ref=f3e3]:
  - heading "Page not found" [level=1] [ref=f3e4]
  - paragraph [ref=f3e5]: Looks like you’ve followed a broken link or entered a URL that doesn’t exist on this site.
  - separator [ref=f3e6]
  - paragraph [ref=f3e7]:
    - text: If this is your site, and you weren’t expecting a 404 for this path, please visit Netlify’s
    - link "“page not found” support guide" [ref=f3e8] [cursor=pointer]:
      - /url: https://answers.netlify.com/t/support-guide-i-ve-deployed-my-site-but-i-still-see-page-not-found/125?utm_source=404page&utm_campaign=community_tracking
    - text: for troubleshooting tips.
```

# Test source

```ts
  1   | // tests/auth.spec.js — GROUP 1: Auth & Routing
  2   | //
  3   | // Covers unauthenticated redirects, per-role home landing, cross-role
  4   | // access blocking, tampered/expired token handling, and logout.
  5   | //
  6   | // NOTE: these tests hit a real Supabase backend and real Netlify route
  7   | // rewrites. They SKIP cleanly until .env.test is populated with real
  8   | // fixture credentials.
  9   | 
  10  | import { test, expect } from '@playwright/test';
  11  | import { loginAs, getProjectRef, isEnvConfigured } from './helpers/auth.js';
  12  | import { installPageErrorCollector, expectCleanPage } from './helpers/expectations.js';
  13  | 
  14  | const REF = getProjectRef();
  15  | const TOKEN_KEY = REF ? `sb-${REF}-auth-token` : 'sb-auth-token';
  16  | const PORTALS = ['/admin', '/teacher', '/parent', '/student'];
  17  | 
  18  | // Each role -> the portal home route it should land on, and a substring
  19  | // expected in the rendered page once logged in.
  20  | const ROLE_HOME = [
  21  |   ['admin', '/admin', /Dashboard|Admin/i],
  22  |   ['teacher', '/teacher', /Dashboard|Teacher|teachersPortal/i],
  23  |   ['parent', '/parent', /Dashboard|Parent|parentsPortal/i],
  24  |   ['student', '/student', /Dashboard|Student|studentPortal/i],
  25  | ];
  26  | 
  27  | test.beforeEach(async ({ page }) => {
  28  |   // Fresh page per test -> clean localStorage -> no cross-test auth bleed.
  29  |   await page.goto('/', { waitUntil: 'domcontentloaded' }).catch(() => {});
  30  | });
  31  | 
  32  | // 1.1 — Unauthenticated users hitting any protected portal are sent to login.
  33  | for (const route of PORTALS) {
  34  |   test(`1.1 unauthenticated ${route} redirects to login`, async ({ page }) => {
  35  |     test.skip(!isEnvConfigured(), '.env.test not populated — skipping unauth redirect check');
  36  |     await page.goto(route);
  37  |     await page.waitForURL(/login/, { timeout: 15000 });
  38  |     expect(page.url()).toMatch(/login/);
  39  |   });
  40  | }
  41  | 
  42  | // 1.2 — Each role lands on its own portal home without a JS error.
  43  | for (const [role, route, headingRe] of ROLE_HOME) {
  44  |   test(`1.2 ${role} lands on ${route}`, async ({ page }) => {
  45  |     test.skip(!isEnvConfigured(role), `no ${role} fixture in .env.test — skipping`);
  46  |     const errors = installPageErrorCollector(page);
  47  |     await loginAs(page, role);
  48  |     await page.goto(route, { waitUntil: 'networkidle' });
  49  |     // Must NOT bounce back to login.
  50  |     await page.waitForLoadState('domcontentloaded');
  51  |     expect(page.url()).not.toMatch(/login/);
  52  |     // Page actually rendered portal content, not a blank redirect stub.
  53  |     const body = await page.locator('body').innerText();
  54  |     expect(body).not.toHaveLength(0);
  55  |     expect(body).toMatch(headingRe);
  56  |     expectCleanPage(errors, [], `${role} home`);
  57  |   });
  58  | }
  59  | 
  60  | // 1.3 — Cross-role access is blocked (every non-matching role/portal pair).
  61  | const CROSS_ROLE_PAIRS = [
  62  |   ['teacher', '/admin'],
  63  |   ['parent', '/admin'],
  64  |   ['student', '/admin'],
  65  |   ['parent', '/teacher'],
  66  |   ['student', '/teacher'],
  67  |   ['admin', '/teacher'],
  68  |   ['student', '/parent'],
  69  |   ['teacher', '/parent'],
  70  |   ['admin', '/parent'],
  71  |   ['parent', '/student'],
  72  |   ['teacher', '/student'],
  73  |   ['admin', '/student'],
  74  | ];
  75  | 
  76  | for (const [role, forbidden] of CROSS_ROLE_PAIRS) {
  77  |   test(`1.3 ${role} cannot access ${forbidden}`, async ({ page }) => {
  78  |     test.skip(!isEnvConfigured(role), `no ${role} fixture in .env.test — skipping`);
  79  |     const errors = installPageErrorCollector(page);
  80  |     await loginAs(page, role);
  81  |     await page.goto(forbidden, { waitUntil: 'domcontentloaded' });
  82  | 
  83  |     let denied = false;
  84  |     await Promise.race([
  85  |       // Path A: app shows the "Access Denied" modal (authGuard overlay).
  86  |       page
  87  |         .waitForSelector('text=Access Denied', { timeout: 8000 })
  88  |         .then(() => {
  89  |           denied = true;
  90  |         }),
  91  |       // Path B: app redirects to login.
  92  |       page.waitForURL(/login/, { timeout: 8000 }).then(() => {
  93  |         denied = true;
  94  |       }),
  95  |     ]).catch(() => {});
  96  | 
  97  |     await page.waitForTimeout(300);
> 98  |     expect(denied, `expected access denial for ${role} on ${forbidden}`).toBe(true);
      |                                                                          ^ Error: expected access denial for parent on /student
  99  |     expectNoPageErrors(errors, `${role} blocked from ${forbidden}`);
  100 |   });
  101 | }
  102 | 
  103 | // 1.4 — Tampered/expired token must not render protected content.
  104 | test('1.4 garbage token redirects to login (no stale content)', async ({ page }) => {
  105 |   test.skip(!isEnvConfigured(), '.env.test not populated — skipping token-tamper check');
  106 | 
  107 |   await page.goto('/');
  108 |   const garbage = JSON.stringify({
  109 |     access_token: 'not.a.real.jwt',
  110 |     refresh_token: 'garbage-refresh',
  111 |     expires_at: Math.floor(Date.now() / 1000) - 3600,
  112 |     token_type: 'bearer',
  113 |     user: {},
  114 |   });
  115 |   await page.evaluate(
  116 |     ([k, v]) => localStorage.setItem(k, v),
  117 |     [TOKEN_KEY, garbage],
  118 |   );
  119 | 
  120 |   await page.goto('/admin', { waitUntil: 'domcontentloaded' });
  121 |   await page.waitForURL(/login/, { timeout: 15000 });
  122 |   expect(page.url()).toMatch(/login/);
  123 | });
  124 | 
  125 | // 1.5 — Logout clears the session: back/direct navigation re-requires login.
  126 | test('1.5 logout clears session (no back-button access)', async ({ page }) => {
  127 |   test.skip(!isEnvConfigured('admin'), 'no admin fixture in .env.test — skipping');
  128 |   const errors = installPageErrorCollector(page);
  129 |   await loginAs(page, 'admin');
  130 |   await page.goto('/admin', { waitUntil: 'networkidle' });
  131 |   expect(page.url()).not.toMatch(/login/);
  132 | 
  133 |   // Trigger logout via the supabase client sign-out, same as the app's
  134 |   // logout button handler would (destroys the local session).
  135 |   await page.evaluate(async () => {
  136 |     await window.supabase.auth.signOut();
  137 |     localStorage.clear();
  138 |   });
  139 | 
  140 |   // Direct URL revisit must not restore the authenticated dashboard.
  141 |   await page.goto('/admin', { waitUntil: 'domcontentloaded' });
  142 |   await page.waitForURL(/login/, { timeout: 15000 });
  143 |   expect(page.url()).toMatch(/login/);
  144 |   expectNoPageErrors(errors, 'logout navigation');
  145 | });
  146 | 
  147 | // Local helper used by 1.3.
  148 | function expectNoPageErrors(errors, context) {
  149 |   if (errors.length > 0) {
  150 |     throw new Error(`JS pageerror(s) (${context}): ${errors.map((e) => e.message).join(' | ')}`);
  151 |   }
  152 | }
  153 | 
```